﻿window.ShowToastr = (type, message) => {
    if (type === "success") {
        toastr.success(message, "!!!");
    }

    if (type === "error") {
        toastr.error(message, "???");
    }
};